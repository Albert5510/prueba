﻿using System;

namespace ej5
{
    class Program
    {
        /* Crea una aplicación para gestionar la personalización de coches en un determinado taller.
          Tendrás que utilizar Enumeraciones NO excluyentes, 
          debes definir la enumeración con un mínimo de 7 colores (incluido el None).
          La aplicación permitirá añadir un color o más a la elección, 
          eliminar un color de los que ya se habían elegido y mostrar los colores elegidos.
          El programa comenzará mostrando un menú, con las tres opciónes y la que nos permita salir.
          Nota: Deberás usar el método LeeEnum, para introducir los datos que se piden al usuario 
          y tendrás que crear, como mínimo, un método para cada una de las posibles opciones del menú.*/
        enum Colores { None = 0, rojo = 1, verde = 2, azul = 3, violeta = 4, negro = 5, blanco = 6 };

        static void Main(string[] args)
        {
            bool salir = false;
            string[] seleccion = new string[7];

            while (salir == false)
            {
                
                System.Console.WriteLine("estas son las opciones");
                System.Console.WriteLine("1.añadir color\n 2.borrar color\n 3.mostrar color\n Pulse cualquier otra letra para salir\n");
                int opcion = Int32.Parse(Console.ReadLine());


                switch (opcion)
                {
                    case 1:
                        añadirColor(seleccion);

                        break;
                    case 2:
                        borrarColor(seleccion);
                        break;
                    case 3:
                        mostrarColor(seleccion);
                        break;
                    default:
                        salir = true;
                        break;
                }
            }
            Console.ReadKey();


        }
        public static Object LeerEnum(Type tipo, string texto, string textoError)
        {
            System.Console.WriteLine(texto);
            try
            {
                Object enumeracion = (Object)Enum.Parse(tipo, Console.ReadLine());
                if (Enum.IsDefined(tipo, enumeracion) | enumeracion.ToString().Contains(","))
                {

                }
                else
                {
                    Console.WriteLine(textoError);
                }
                return enumeracion;
            }
            catch (ArgumentException)
            {
                Console.WriteLine(textoError);
                return null;
            }


        }
        public static void añadirColor(string[] seleccion)
        {
            Colores opcion = (Colores)LeerEnum(typeof(Colores), "¿que Colores quieres?", "opcion incorrecta");
            for (int i = 0; i < 7; i++)
            {
                if (seleccion[i] == null)
                {
                    seleccion[i] = new string(opcion.ToString());
                    i = 7;
                }
            }

        }
        public static void borrarColor(string[] seleccion)
        {
            Colores colorBorrar = (Colores)LeerEnum(typeof(Colores), "¿que Colores quieres?", "opcion incorrecta");
            for (int i = 0; i < 7; i++)
            {
                if (seleccion[i] != null)
                {
                    if (seleccion[i].Equals(colorBorrar.ToString()))
                    {
                        seleccion[i] = null;
                    }
                }
            }
        }
        public static void mostrarColor(string[] seleccion)
        {
            for (int i = 0; i < 7; i++)
            {
                if (seleccion[i] != null)
                {
                    System.Console.WriteLine(seleccion[i]);
                }
            }
        }
    }
}
