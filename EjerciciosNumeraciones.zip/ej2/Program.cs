﻿using System;

namespace ej2
{
    class Program
    {
        /* Crea un programa que permita controlar el coste del abono de transporte urbano de una determinada ciudad.
          Existirán diferentes tipos de abonos: 
          QuinceDias, TreintaDias, FamiliasNumerosas, TerceraEdad, Discapacidad, Juvenil, Infantil, Turístico.
          El coste del viaje de cada una de estas tarífas será, 
          respectivamente, el siguiente: 0.70, 0.60, 0.50, 0.30, 0.20, 0.65, 0.35, 0.90. 
          Frente al precio de 1.20 del viaje sin tarifa.
          Los abonos se podrán comprar para un mínimo de 7 días 
          (descartando los dos primeros que son para 15 y 30 días respectivamente), y un máximo de 60 días.
          El programa deberá:
          pedir al usuario el tipo de abono que quiere comprar, y para cuantos días 
          (teniendo en cuenta que los dos primeros no necesitan este datos).
          Calcular el coste del Abono, mostrando total a pagar por pantalla.
          Controlar que la entrada de datos es correcta, mostrando mensajes de aviso en caso contrario.
          Se deberán crear los métodos necesarios para que el código siga las normas de modularidad 
          que ya vimos en temas anteriores.
          💡 Tip: Para una mejor codificación deberás asociar los precios del viaje a la enumeración. 
          Como a las enumeraciones solo se pueden asociar a valores enteros, 
          podrás dividir entre 100 el valor asociado para que sea real.*/
        static void Main(string[] args)
        {
            float precio = 0;
            int dias = 0;
            System.Console.WriteLine("que tipo de bono desea");
            System.Console.WriteLine(" 1.QuinceDias\n 2.TreintaDias\n 3.FamiliasNumerosas\n 4.Discapacidad\n 5.Juvenil\n 6.Infantil\n 7.Turistico");
            int opcion = Int32.Parse(Console.ReadLine());
            
            if (opcion != 1 && opcion != 2)
            {
                System.Console.WriteLine("inserte numero de dias");
                dias = Int32.Parse(Console.ReadLine());
            }
            if (dias >= 7 && dias <= 60)
            {


                switch (opcion)
                {
                        case 1:
                        dias = 15;
                        precio = dias * (float)bono.QuinceDias/100;
                        break;
                        case 2:
                        dias = 30;
                        precio = dias * (float)bono.TreintaDias/100;
                        break;
                        case 3:
                        precio = dias * (float)bono.FamiliasNumerosas/100;
                        break;
                        case 4:
                        precio = dias * (float)bono.TerceraEdad/100;
                        break;
                        case 5:
                        precio = dias * (float)bono.Discapacidad/100;
                        break;
                        case 6:
                        precio = dias * (float)bono.Juvenil/100;
                        break;
                        case 7:
                        precio = dias * (float)bono.Infantil/100;
                        break;
                        case 8:
                        precio = dias * (float)bono.Turístico/100;
                        break;
                        default:
                        System.Console.WriteLine("bono incorrecto");
                        break;
                }
                System.Console.WriteLine("el precio es de " + precio + " euros");
            }
            else{
                System.Console.WriteLine("dias incorrectos");
            }
            
            Console.ReadKey();
        }
        enum bono
        {
            QuinceDias = 70, TreintaDias = 60, FamiliasNumerosas = 50, TerceraEdad = 30, Discapacidad = 20, Juvenil = 65, Infantil = 35, Turístico = 90
        }

    }
}
