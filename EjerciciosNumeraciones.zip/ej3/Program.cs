﻿using System;

namespace ej3
{
    class Program
    {
        /*Crea un método genérico llamado LeeEnum,
        que permitirá recoger un string del usuario hasta que coincida con un elemento de la enumeración X. 
        El método tendrá que comprobar si la string introducida por el usuario pertenece a la enumeración, 
        si pertenece devolverá el elemento de la enumeración que coincida, 
        si nó mostrará todos los elementos de la enumeración y volverá a pedir el string al usuario.
        Este método tendrá la siguiente signatura:
        public static Object LeerEnum(Type tipo, string texto, string textoError);
        Donde:
        tipo: El tipo de la enumeración obtenido con la función typeof(IdentificadorEnumeracion).
        texto: El texto que se muestra para pedir al usuario que introduzca el valor de la enumeración.
        textoError: El texto que se mostrará si el valor que se introduce no pertenece a la enumeración.
        Modifica el Ejercicio 2 para usar el método LeeEnum a la hora de recoger el tipo de Abono a comprar.
        👉Pista: Este método utilizará Enum.IsDefined para comprobar si el valor pertenece a la enumeración, 
        Enum.Parse para convertir el string a tipo Enum y Enum.GetNames 
        para crear el array que se mostrará en caso de que el dato sea erróneo.*/
        static void Main(string[] args)
        {
            float precio = 0;
            int dias = 0;
            System.Console.WriteLine(" 1.QuinceDias\n 2.TreintaDias\n 3.FamiliasNumerosas\n 4.Discapacidad\n 5.Juvenil\n 6.Infantil\n 7.Turistico");
            bono opcion = (bono)LeerEnum(typeof(bono),"que tipo de bono desea","opcion incorrecta");
            if (opcion != bono.QuinceDias && opcion != bono.TreintaDias)
            {
                System.Console.WriteLine("inserte numero de dias");
                dias = Int32.Parse(Console.ReadLine());
            }
            else if(opcion == bono.QuinceDias){
                dias = 15;
            }
            else if (opcion == bono.TreintaDias){
                dias = 30;
            }
            if (dias >= 7 && dias <= 60)
            {


                switch (opcion)
                {
                    case bono.QuinceDias:
                        dias = 15;
                        precio = dias * (float)bono.QuinceDias / 100;
                        break;
                    case bono.TreintaDias:
                        dias = 30;
                        precio = dias * (float)bono.TreintaDias / 100;
                        break;
                    case bono.FamiliasNumerosas:
                        precio = dias * (float)bono.FamiliasNumerosas / 100;
                        break;
                    case bono.TerceraEdad:
                        precio = dias * (float)bono.TerceraEdad / 100;
                        break;
                    case bono.Discapacidad:
                        precio = dias * (float)bono.Discapacidad / 100;
                        break;
                    case bono.Juvenil:
                        precio = dias * (float)bono.Juvenil / 100;
                        break;
                    case bono.Infantil:
                        precio = dias * (float)bono.Infantil / 100;
                        break;
                    case bono.Turístico:
                        precio = dias * (float)bono.Turístico / 100;
                        break;
                    default:
                        System.Console.WriteLine("bono incorrecto");
                        break;
                }
                System.Console.WriteLine("el precio es de " + precio + " euros");
            }
            else
            {
                System.Console.WriteLine("dias incorrectos");
            }

            Console.ReadKey();
        }
        enum bono
        {
            QuinceDias = 70, TreintaDias = 60, FamiliasNumerosas = 50, TerceraEdad = 30, Discapacidad = 20, Juvenil = 65, Infantil = 35, Turístico = 90
        }
        public static Object LeerEnum(Type tipo, string texto, string textoError)
        {
            System.Console.WriteLine(texto);
            try
            {
                Object enumeracion = (Object)Enum.Parse(tipo, Console.ReadLine());
                if (Enum.IsDefined(tipo, enumeracion) | enumeracion.ToString().Contains(",")){
                    
                }
                else{
                    Console.WriteLine(textoError);
                }
                    return enumeracion;
            }
            catch (ArgumentException)
            {
                Console.WriteLine(textoError);
                return null;
            }
            

        }

    }
}
